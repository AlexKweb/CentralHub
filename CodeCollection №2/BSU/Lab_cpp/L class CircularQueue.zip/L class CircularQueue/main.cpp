#include <iostream>
#include "queue.h"

void printQueue(ArrayQueue q) {
    std::cout << "Queue content (front -> back): ";
    while (!q.isEmpty()) {
        std::cout << q.pop_front() << " ";
    }
    std::cout << std::endl;
}

int main() {
    ArrayQueue q(5);

    try {
        q.push_back(10);
        q.push_back(20);
        q.push_back(30);
        q.push_back(40);
        q.push_back(50);

        printQueue(q);

        std::cout << "Pop front: " << q.pop_front() << std::endl;
        std::cout << "Pop front: " << q.pop_front() << std::endl;

        q.push_back(60);
        q.push_back(70);

        printQueue(q);

        // provoke overflow
        q.push_back(80);
    } catch (const QueueException& ex) {
        std::cout << "Caught exception: " << ex.what() << std::endl;
    }

    try {
        ArrayQueue emptyQ(2);
        emptyQ.pop_front();  // provoke underflow
    } catch (const QueueException& ex) {
        std::cout << "Caught exception: " << ex.what() << std::endl;
    }

    // demonstrate copy constructor
    ArrayQueue copyQ(q);
    std::cout << "Copied queue: ";
    printQueue(copyQ);

    return 0;
}
