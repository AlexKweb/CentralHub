#ifndef QUEUE_H
#define QUEUE_H

#include <exception>
#include <string>

class QueueException : public std::exception {
    std::string message;

public:
    explicit QueueException(const std::string& msg) : message(msg) {}
    const char* what() const noexcept override { return message.c_str(); }
};

class ArrayQueue {    /* кольцевая очередь на массиве */
    int size;         /* размерность массива */
    int* p;           /* указатель на массив */
    int head;         /* индекс первого занятого элемента */
    int tail;         /* индекс первого свободного элемента для вставки */
    int n;            /* количество элементов в очереди */

public:
    explicit ArrayQueue(int size);       /* инициализация очереди */
    ArrayQueue(const ArrayQueue& q);     /* конструктор копирования */
    ~ArrayQueue();                       /* разрушить очередь */

    void push_back(int value);           /* втолкнуть элемент в очередь */
    int pop_front();                     /* удалить элемент из очереди */
    bool isEmpty() const;                /* пустая очередь? */
    bool isFull() const;                 /* полная очередь? */
};



#endif
